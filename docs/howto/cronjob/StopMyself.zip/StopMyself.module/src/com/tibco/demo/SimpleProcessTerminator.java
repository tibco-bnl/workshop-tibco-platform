package com.tibco.demo;


import java.util.Optional;


public class SimpleProcessTerminator {
    public static boolean terminateProcess(long pid) {
        Optional<ProcessHandle> processHandle = ProcessHandle.of(pid);
        
        if (processHandle.isPresent()) {
        	System.exit((int) pid);
            return true;
        }
        
        return false;
    }

	
}
