package com.tibco.demo;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class KillProcess {

    /**
     * Kills a Linux process given its PID.
     * 
     * @param pid Linux process ID
     * @return result message (success/failure)
     */
    public static String killProcess(String pid) {
        try {
            // Use ProcessBuilder (safer than Runtime.exec)
            ProcessBuilder pb = new ProcessBuilder("kill", "-s SIGINT", pid);
            Process process = pb.start();
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                return "Process " + pid + " killed successfully.";
            } else {
                // Capture error message from stderr
                BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                StringBuilder errorMsg = new StringBuilder();
                String line;
                while ((line = errorReader.readLine()) != null) {
                    errorMsg.append(line).append("\n");
                }
                return "Failed to kill process " + pid + ". Error: " + errorMsg.toString().trim();
            }
        } catch (Exception e) {
            return "Exception occurred while killing process " + pid + ": " + e.getMessage();
        }
    }
}